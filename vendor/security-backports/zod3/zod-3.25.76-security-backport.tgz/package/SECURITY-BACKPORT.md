# Local Zod3 security backport

This is not an official Zod release. Root imports retain the3.25.76 Zod3 API and declared version; maintained v4 subpaths are copied from official4.6.7. Its v3 implementation has early upper-bound rejection for arrays, sets and fixed-length tuples. MIT license is retained. The original vulnerability range will still match; use the verified package/source hash and regression evidence rather than ignoring the advisory.

Unbounded collections are unchanged, as in upstream4.6.6. No library can preserve unlimited valid-input behavior while guaranteeing a fixed CPU budget. Consumers must impose request sizes and schema bounds. Zod3 Map has no built-in size bound. Oversized invalid collections abort before child validators and enclosing refinements. Normal inputs within declared bounds retain Zod3 validation/error behavior.
